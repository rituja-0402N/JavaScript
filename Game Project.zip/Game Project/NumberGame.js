var guessItem=null;
var interval = 60;
var solution = null;
var score = 0;
var results = [];
var gameOver = false;

function setup() {
  createCanvas(800, 300);

}

function draw() {

  var gameTotal = gameScore(results);

  if(gameTotal.loss >= 3 || gameTotal.total >= 10){
    displayGameOver(gameTotal);
    gameOver = true;
    return;
  }

  background(220);

  if(frameCount === 1 || frameCount % interval === 0)
  {
    solution = null;
    guessItem = new GuessItem(width/2,height/2, 10);
  }
  if(guessItem){
      guessItem.render();
  }
  if(solution == true || solution == false){
    solutionMessage(gameScore.total,solution);
  }
}

function gameScore(score){
  //console.log(score + "this.results");
  var wins = 0;
  var losses = 0;
  var total = score.length;

  for(var i = 0 ; i < total; i++ ){
    var item = score[i];
    if(item === true){
       wins = wins + 1;
    }else{
      losses = losses + 1;
    }
  }

  return {win:wins,loss:losses,total:total};
}

function displayGameOver(score){

  push();
  background(255);
  textAlign(CENTER,CENTER);
  translate(width/2,height/2);

  textSize(20);
  fill(237,34,10);
  text("GAME OVER!!",0,0);

  textSize(30);
  fill(0);
  translate(0,36);
  text("You have " + score.win + " correct guesses.", 0,0);

  var alternateValue = map(sin(frameCount/10),-1,1,0,255);

  fill(0,200,100,alternateValue);
  textSize(20);
  translate(0,80);
  text("Press Enter",0,0);
  pop();
}

function restartTheGame(){
  results = [];
  solution = null;
  gameOver = false;
  }

function keyPressed(){
  if(gameOver === true){
  if(keyCode === ENTER){
     console.log("Game is Over");
     restartTheGame();
    return;
}
  }
  if(guessItem !== null){
  solution = guessItem.solved(key);
    if(solution){
      results.push(true);
    }else{
      results.push(false);
    }
  console.log("you presssed ", key);
  guessItem = null;
}else{
  console.log("Nothing to play.")
 }
}

function solutionMessage(seed, solution){
  var trueMessages =[
    "Good Job!",
    'Doing Great!' ,
    'Impressive',
    'Amazing!'
  ];

   var falseMessages = [
    //'Oops!',
    //'Try Again!',
     '🤨',
     ':('
  ];
  var messages;

  push();
  textAlign(CENTER,CENTER);
  textSize(36);
  fill(225,30,30);
  randomSeed(seed * 10000);

  if(solution === true){
    background(255);
    messages = trueMessages;
  }
  else if(solution === false) {
    background(0);
    messages = falseMessages;
  }

  translate(width/2,height/2);
  text(messages[parseInt(random(messages.length),10)],0,0);
  pop();


}
function GuessItem(x,y,scl){
  this.x = x;
  this.y = y;
  this.scale = scl;
  this.scaleIncrement = 0.1;
  this.content = getContent();
  this.alpha = 255;
  this.alphaDecrement = 3;
  this.contentMap ={
    '1' : 'one',
    '2' : 'two',
    '3' : 'three',
    '4' : 'four',
    '5' : 'five',
    '6' : 'six',
    '7' : 'seven',
    '8' : 'eight',
    '9' : 'nine',
    '0' : 'zero'
  };


  function getContent(){
    return String(parseInt(random(10),10));
  }


  this.solved = function(input){
    if(input === this.content){
      this.solved = true;
      //console.log("true"+ this.content);
      }
    else{
      this.solved = false;
      //console.log("false" + this.content + input);
    }
    return this.solved
  }

  this.render = function(){

    push();
    fill(0,this.alpha);
    textAlign(CENTER,CENTER);
    translate(this.x,this.y);
    scale(this.scale);
    text(this.contentMap[this.content],0,0);
    this.scale = this.scale + this.scaleIncrement;
    this.alpha = this.alpha - this.alphaDecrement;
    pop();
  }
}
